package com.FUTBOLARIOS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/*
@SpringBootTest
class FutbolariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/