package com.FUTBOLARIOS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutbolariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutbolariosApplication.class, args);
	}

}
