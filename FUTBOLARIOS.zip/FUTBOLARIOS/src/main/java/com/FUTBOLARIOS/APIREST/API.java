package com.FUTBOLARIOS.APIREST;
/*
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.noticias;
import com.FUTBOLARIOS.Entity.usuarios;
import com.FUTBOLARIOS.Repository.EquiposRepository;
import com.FUTBOLARIOS.Repository.NoticiasRepository;
import com.FUTBOLARIOS.Repository.UsuariosRepository;

@RestController
public class API 
{
	@Autowired
	private EquiposRepository Equipo;
	
	@Autowired
	private NoticiasRepository Noticia;
	
	@Autowired
	private UsuariosRepository Usuario;
	
	private List<String> correos = new ArrayList<String>();
    
	@RequestMapping(value = "/Administrador/Menu/Noticia/CrearNoticia/Final", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public List<String> CreoNoticia(Model model, @RequestParam (required = false, defaultValue = "") String NombreEscritor, 
			@RequestParam (required = false, defaultValue = "") String ApellidosEscritor, @RequestParam (required = false, defaultValue = "") String Titulo, 
			@RequestParam (required = false, defaultValue = "") String Texto, @RequestParam (required = false, defaultValue = "") String Fecha, 
			@RequestParam (required = false, defaultValue = "") String equipo)
	{
		//Guardo noticia en base de datos.
		equipos EQ = Equipo.getOne(equipo);
	    noticias NO = new noticias(NombreEscritor,ApellidosEscritor,Titulo,Texto,Fecha,EQ);
	    Noticia.save(NO);
	    
	    //Meter valores en la API.
	    equipos equipoFinal = Equipo.getOne(equipo);
	    
	    List<usuarios> listaUsuarios = new ArrayList<usuarios>();
	    listaUsuarios = Usuario.findByNombreEQ(equipoFinal);
	    
	    for(usuarios  x:listaUsuarios)
	    {
	    	correos.add(x.getCorreo());
	    }
	    
		return correos;
	}
	
	@RequestMapping(value = "/Administrador/Menu/Noticia/CrearNoticia/Final", method = RequestMethod.GET)
	public List<String> DevuelvoAnuncio()
	{	
		 return correos;
	}
}
*/