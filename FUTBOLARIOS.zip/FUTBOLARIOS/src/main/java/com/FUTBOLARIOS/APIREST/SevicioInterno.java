package com.FUTBOLARIOS.APIREST;
/*
import java.beans.JavaBean;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@RestController
public class SevicioInterno 
{
	@Autowired
    private JavaMailSender mailSender;
	
	@GetMapping("/EnviarCorreos")
	public void enviarCorreos()
	{
	   //Obtengo correos.
	   RestTemplate restTemplate = new RestTemplate();

	   String url = "https://localhost:8443/Administrador/Menu/Noticia/CrearNoticia/Final";
	
	   List<String> correos = restTemplate.getForObject(url, List.class);
	   
	   //Envio correos.
	   SimpleMailMessage email = new SimpleMailMessage();
	   
	   for(String co : correos)
	   {
          email.setFrom(co);
          email.setTo("Futbolarios");
          email.setSubject("Futbolarios");
          email.setText("Se acaba de publicar una noticia nueva de su equipo favorito. Visite Futbolarios.com para verla.");
          mailSender.send(email);  
	   } 	   
	}
}
*/