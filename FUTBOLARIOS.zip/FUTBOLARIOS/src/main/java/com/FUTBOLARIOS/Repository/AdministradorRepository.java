package com.FUTBOLARIOS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FUTBOLARIOS.Entity.administrador;

public interface AdministradorRepository extends JpaRepository<administrador, Integer> 
{

}
