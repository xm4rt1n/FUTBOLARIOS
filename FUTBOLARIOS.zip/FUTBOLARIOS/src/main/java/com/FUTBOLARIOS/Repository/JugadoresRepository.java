package com.FUTBOLARIOS.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.FUTBOLARIOS.Entity.jugadores;

public interface JugadoresRepository extends JpaRepository<jugadores,Integer> 
{
	//BUSQUEDAS PERSONALIZADAS: BUSCA JUGADORES DE DICHO EQUIPO.
	@Query(
       value = "SELECT * FROM futbolarios2.jugadores WHERE nombreeq_equipos_nombre = \"Barcelona\" ", 
	   nativeQuery = true)
	List<jugadores>findAllDateTeamBarcelona();	
	
	@Query(
	   value = "SELECT * FROM futbolarios2.jugadores WHERE nombreeq_equipos_nombre = \"Real Madrid\" ", 
	   nativeQuery = true)
    List<jugadores>findAllDateTeamRealMadrid();	
			
	@Query(
	   value = "SELECT * FROM futbolarios2.jugadores WHERE nombreeq_equipos_nombre = \"Sevilla\" ", 
	   nativeQuery = true)
	List<jugadores>findAllDateTeamSevila();	

	@Query(
	   value = "SELECT * FROM futbolarios2.jugadores WHERE nombreeq_equipos_nombre = \"Atlético de Madrid\" ", 
	   nativeQuery = true)
    List<jugadores>findAllDateTeamAtleticoDeMadrid();	
}