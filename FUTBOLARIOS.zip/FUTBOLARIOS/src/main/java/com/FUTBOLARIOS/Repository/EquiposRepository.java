package com.FUTBOLARIOS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FUTBOLARIOS.Entity.equipos;

public interface EquiposRepository extends JpaRepository<equipos,String> 
{
	
}

