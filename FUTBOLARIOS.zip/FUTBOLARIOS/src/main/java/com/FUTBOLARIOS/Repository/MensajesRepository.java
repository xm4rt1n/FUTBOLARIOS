package com.FUTBOLARIOS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FUTBOLARIOS.Entity.mensajes;

public interface MensajesRepository extends JpaRepository<mensajes,Integer> 
{

}
