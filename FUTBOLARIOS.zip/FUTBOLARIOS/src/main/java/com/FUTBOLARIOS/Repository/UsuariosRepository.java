package com.FUTBOLARIOS.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.jugadores;
import com.FUTBOLARIOS.Entity.usuarios;

public interface UsuariosRepository extends JpaRepository<usuarios, String> {
	
	Optional<usuarios> findByApodo(String apodo);
	
	List<usuarios>findByNombreEQ(equipos equipo);
	
}

