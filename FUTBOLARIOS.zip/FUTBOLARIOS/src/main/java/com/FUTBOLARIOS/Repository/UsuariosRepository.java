package com.FUTBOLARIOS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FUTBOLARIOS.Entity.usuarios;

public interface UsuariosRepository extends JpaRepository<usuarios, String> 
{
	
}

