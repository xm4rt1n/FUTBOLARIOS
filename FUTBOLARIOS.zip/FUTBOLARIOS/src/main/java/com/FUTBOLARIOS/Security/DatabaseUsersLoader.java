package com.FUTBOLARIOS.Security;
/*
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.usuarios;
import com.FUTBOLARIOS.Repository.EquiposRepository;
import com.FUTBOLARIOS.Repository.UsuariosRepository;

@Component
public class DatabaseUsersLoader {

    @Autowired
    private UsuariosRepository UR;
    
    @Autowired
    private EquiposRepository EQ;
    
    @Autowired
	private PasswordEncoder passwordEncoder;

    @PostConstruct
    private void initDatabase() {
    	
    	equipos equipo = EQ.getOne("Real Madrid");

    	UR.save(new usuarios("Prueba1","Prueba1","Prueba1",14,"Prueba1@gmail.com", passwordEncoder.encode("Prueba1"),equipo, "USER"));
    	UR.save(new usuarios("Prueba2","Prueba2","Prueba2",14,"Prueba2@gmail.com", passwordEncoder.encode("Prueba2"),equipo, "USER", "ADMIN"));
    }
}
*/