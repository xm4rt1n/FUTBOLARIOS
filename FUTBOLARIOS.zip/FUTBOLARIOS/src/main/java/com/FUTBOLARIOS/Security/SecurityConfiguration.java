package com.FUTBOLARIOS.Security;

import java.security.SecureRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter 
{
	@Autowired
	RepositoryUserDetailsService userDetailsService;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(10, new SecureRandom());
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}
	 
	 @Override
	 protected void configure(HttpSecurity http) throws Exception {
	 
	 //Páginas publicas
     //Index
	 http.authorizeRequests().antMatchers("/").permitAll(); 
	 //Noticias
	 http.authorizeRequests().antMatchers("/Noticias").permitAll(); 
	 http.authorizeRequests().antMatchers("/Noticias/Avanzado").permitAll(); 
	 //Equipos
	 http.authorizeRequests().antMatchers("/Equipos").permitAll(); 
	 //Jugadores
	 http.authorizeRequests().antMatchers("/Jugadores").permitAll();
	 http.authorizeRequests().antMatchers("/Jugadores/Avanzado").permitAll();
     //Usuarios
	 http.authorizeRequests().antMatchers("/Usuario").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/Registrarse").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/Registrarse/Avanzado").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/IniciarSesion").permitAll();

	 //Páginas privadas
	 //USER
	 http.authorizeRequests().antMatchers("/Bifurcacion").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Usuario/Menu").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Usuario/Perfil").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Usuario/Perfil/EliminarPerfil").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Usuario/Perfil/ModificarPerfil").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Usuario/Perfil/ModificarPerfil/Fin").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Foro").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Foro/ComentarioRealizado").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Foro/EliminarUsuario").hasAnyRole("USER");
	 
	 //ADMIN
	 http.authorizeRequests().antMatchers("/Administrador/Menu2").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Noticias").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Noticia/Eliminar").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Noticia/EliminarNoticia/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Noticia/CrearNoticia").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Noticia/CrearNoticia/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Equipos").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Equipos/Eliminar").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Equipos/Eliminar/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Equipos/CrearEquipo").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Equipos/CrearEquipo/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Jugadores").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Jugadores/MenuEliminar").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Jugadores/MenuEliminar/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Jugadores/MenuCrear").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Jugadores/MenuCrear/Final").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Usuarios").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Usuarios/Eliminar").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/CrearAdministrador").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/CrearAdministrador/Avanzado").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Foro").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Administrador/Menu/Foro/Eliminar").hasAnyRole("ADMIN");
	
	 //Formulario de inicio de sesión
	 http.formLogin().loginPage("/Usuario/IniciarSesion");
	 http.formLogin().usernameParameter("username");
	 http.formLogin().passwordParameter("password");
	 http.formLogin().defaultSuccessUrl("/Bifurcacion");
	 http.formLogin().failureUrl("/loginError");
	 
	 //Cerrar sesión
	 http.logout().logoutUrl("/logout");
	 http.logout().logoutSuccessUrl("/");
     
	 //Disable CSRF at the moment
	 http.csrf().disable();	 
	 }
}



