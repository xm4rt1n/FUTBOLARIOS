package com.FUTBOLARIOS.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter 
{
	 @Override
	 protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		 PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

		 auth.inMemoryAuthentication().withUser("user").password(encoder.encode("pass")).roles("USER");

		 auth.inMemoryAuthentication().withUser("admin").password(encoder.encode("adminpass")).roles("USER", "ADMIN");
	 }
	 
	 @Override
	 protected void configure(HttpSecurity http) throws Exception {
	 
	 //Páginas publicas
     //Index
	 http.authorizeRequests().antMatchers("/").permitAll(); 
	 //Jugadores
	 http.authorizeRequests().antMatchers("/Jugadores").permitAll();
	 http.authorizeRequests().antMatchers("/Jugadores/Avanzado").permitAll();
     //Usuarios
	 http.authorizeRequests().antMatchers("/Usuario").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/Registrarse").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/Registrarse/Avanzado").permitAll();
	 http.authorizeRequests().antMatchers("/Usuario/IniciarSesion").permitAll();

	 //Páginas privadas
	 http.authorizeRequests().antMatchers("/Bifurcacion").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Equipos").hasAnyRole("ADMIN");
	 http.authorizeRequests().antMatchers("/Noticias").hasAnyRole("USER");
	 http.authorizeRequests().antMatchers("/Noticias/Avanzado").hasAnyRole("USER");
	 
	 //Formulario de inicio de sesión
	 http.formLogin().loginPage("/Usuario/IniciarSesion");
	 http.formLogin().usernameParameter("username");
	 http.formLogin().passwordParameter("password");
	 http.formLogin().defaultSuccessUrl("/Bifurcacion");
	 http.formLogin().failureUrl("/loginError");
	 
	 //Cerrar sesión
	 http.logout().logoutUrl("/logout");
	 http.logout().logoutSuccessUrl("/");
     
	 //Disable CSRF at the moment
	 http.csrf().disable();
	 }
}



