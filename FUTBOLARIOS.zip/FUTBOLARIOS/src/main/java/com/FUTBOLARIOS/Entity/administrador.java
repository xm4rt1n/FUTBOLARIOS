package com.FUTBOLARIOS.Entity;
/*
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class administrador {

	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
     private int Codigo_Administrador;
	 
	 private String Nombre;
	 private String Contraseña;
	 
	 //CONSTRUCTOR. 
	 protected administrador() {}
	 
	 public administrador(String NM, String CÑ)
	 {
		 Nombre=NM;
		 Contraseña=CÑ;
	 }

	//GETTERS SETTERS Y TOSTRING.
	public int getCodigo_Administrador() {
		return Codigo_Administrador;
	}

	public void setCodigo_Administrador(int codigo_Administrador) {
		Codigo_Administrador = codigo_Administrador;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getContraseña() {
		return Contraseña;
	}

	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}

	@Override
	public String toString() {
		return "administrador [Codigo_Administrador=" + Codigo_Administrador + ", Nombre=" + Nombre + ", Contraseña="
				+ Contraseña + "]";
	}

	//HASHCODE Y EQUALS.
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Nombre == null) ? 0 : Nombre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		administrador other = (administrador) obj;
		if (Nombre == null) {
			if (other.Nombre != null)
				return false;
		} else if (!Nombre.equals(other.Nombre))
			return false;
		return true;
	}
}*/
