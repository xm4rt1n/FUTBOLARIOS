package com.FUTBOLARIOS.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class mensajes {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int Codigo_Mensaje;

	private String Texto;
	private String Fecha;
	
	@ManyToOne
	private usuarios Apodo;

	//CONSTRUCTOR. 
    protected mensajes(){}
    
    public mensajes(String TX, String FC, usuarios AP)
    {
    	this.Texto=TX;
    	this.Fecha=FC;
    	this.Apodo=AP;
    }

    //GETTERS, SETTERS y TOSTRING
	public int getCodigo_Mensaje() {
		return Codigo_Mensaje;
	}

	public void setCodigo_Mensaje(int codigo_Mensaje) {
		Codigo_Mensaje = codigo_Mensaje;
	}

	public usuarios getApodo() {
		return Apodo;
	}

	public void setApodo(usuarios apodo) {
		Apodo = apodo;
	}

	public String getTexto() {
		return Texto;
	}

	public void setTexto(String texto) {
		Texto = texto;
	}

	public String getFecha() {
		return Fecha;
	}

	public void setFecha(String fecha) {
		Fecha = fecha;
	}

	@Override
	public String toString() {
		return "mensajes [Codigo_Mensaje=" + Codigo_Mensaje + ", Texto=" + Texto + ", Fecha=" + Fecha + ", Apodo="
				+ Apodo + "]";
	}
}
    