package com.FUTBOLARIOS.Entity;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class usuarios 
{
	 @Id
	 private String Apodo;
	 
	 private String Nombre;
	 private String Apellidos;
	 private int Edad;
	 private String Correo;
	 private String Contraseña;
	 
	 @ManyToOne
     private equipos NombreEQ;
	 
	//CONSTRUCTOR. 
    protected usuarios() {}
		    
	public usuarios(String AD, String NM, String AP, int ED, String CR, String CN, equipos EN)
	{
	   this.Apodo=AD;
       this.Nombre=NM;
       this.Apellidos=AP;
       this.Edad=ED;
       this.Correo=CR;
       this.Contraseña=CN;
       this.NombreEQ=EN;
	}

	//GETTERS, SETTERS y TOSTRING
	public String getNombre() {
		return Nombre;
	}

	public String getApodo() {
		return Apodo;
	}

	public void setApodo(String apodo) {
		Apodo = apodo;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellidos() {
		return Apellidos;
	}

	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		Edad = edad;
	}

	public String getCorreo() {
		return Correo;
	}

	public void setCorreo(String correo) {
		Correo = correo;
	}

	public String getContraseña() {
		return Contraseña;
	}

	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}

	public equipos getEquipos_Nombre() {
		return NombreEQ;
	}

	public void setEquipos_Nombre(equipos equipos_Nombre) {
		this.NombreEQ = equipos_Nombre;
	}

	@Override
	public String toString() {
		return "usuarios [Apodo=" + Apodo + ", Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", Edad=" + Edad
				+ ", Correo=" + Correo + ", Contraseña=" + Contraseña + ", equipos_Nombre=" + NombreEQ + "]";
	}

	//HASHCODE Y EQUALS
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Apodo == null) ? 0 : Apodo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		usuarios other = (usuarios) obj;
		if (Apodo == null) {
			if (other.Apodo != null)
				return false;
		} else if (!Apodo.equals(other.Apodo))
			return false;
		return true;
	}	 
}