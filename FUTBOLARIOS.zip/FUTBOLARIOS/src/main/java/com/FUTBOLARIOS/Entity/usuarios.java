package com.FUTBOLARIOS.Entity;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class usuarios 
{
	 @Id
	 private String apodo;
	 
	 private String Nombre;
	 private String Apellidos;
	 private int Edad;
	 private String Correo;
	 private String Contrasena;
	 
	 @ManyToOne
     private equipos nombreEQ;
	 
	 @ElementCollection(fetch = FetchType.EAGER)
	 private List<String> roles;

	//CONSTRUCTOR. 
    public usuarios() {}
		    
	public usuarios(String AD, String NM, String AP, int ED, String CR, String CN, equipos EN, String... roles)
	{
	   this.apodo=AD;
       this.Nombre=NM;
       this.Apellidos=AP;
       this.Edad=ED;
       this.Correo=CR;
       this.Contrasena=CN;
       this.nombreEQ=EN;
       this.roles = List.of(roles);
	}

	//GETTERS, SETTERS y TOSTRING
	public String getNombre() {
		return Nombre;
	}

	public String getApodo() {
		return apodo;
	}

	public void setApodo(String apodo) {
		apodo = apodo;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellidos() {
		return Apellidos;
	}

	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		Edad = edad;
	}

	public String getCorreo() {
		return Correo;
	}

	public void setCorreo(String correo) {
		Correo = correo;
	}

	public String getContrasena() {
		return Contrasena;
	}

	public void setContrasena(String contraseña) {
		Contrasena = contraseña;
	}

	public equipos getEquipos_Nombre() {
		return nombreEQ;
	}

	public void setEquipos_Nombre(equipos equipos_Nombre) {
		this.nombreEQ = equipos_Nombre;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "usuarios [Apodo=" + apodo + ", Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", Edad=" + Edad
				+ ", Correo=" + Correo + ", Contraseña=" + Contrasena + ", NombreEQ=" + nombreEQ + ", roles=" + roles
				+ "]";
	}

	//HASHCODE Y EQUALS
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apodo == null) ? 0 : apodo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		usuarios other = (usuarios) obj;
		if (apodo == null) {
			if (other.apodo != null)
				return false;
		} else if (!apodo.equals(other.apodo))
			return false;
		return true;
	}	 
}