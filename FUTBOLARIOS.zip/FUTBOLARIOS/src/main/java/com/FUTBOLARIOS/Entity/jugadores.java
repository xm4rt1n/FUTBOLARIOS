package com.FUTBOLARIOS.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class jugadores {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int Codigo_Jugador;
	
	private String Nombre;
	private int Edad;
	private String Nacionalidad;
	private int Goles;
	private int Asistencias;
	private int Partidos_Jugados;
	
	@ManyToOne
	private equipos NombreEQ;
	
	//CONSTRUCTOR. 
    protected jugadores() {}
    
    public jugadores(String NM, int ED, String NC, int GO, int AS, int PJ, equipos EN)
    {
    	this.Nombre=NM;
    	this.Edad=ED;
    	this.Nacionalidad=NC;
    	this.Goles=GO;
    	this.Asistencias=AS;
    	this.Partidos_Jugados=PJ;
    	this.NombreEQ=EN;
    }

    //GETTERS, SETTERS y TOSTRING
	public int getCodigo_Jugador() {
		return Codigo_Jugador;
	}

	public void setCodigo_Jugador(int codigo_Jugador) {
		Codigo_Jugador = codigo_Jugador;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		Edad = edad;
	}

	public String getNacionalidad() {
		return Nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		Nacionalidad = nacionalidad;
	}

	public int getGoles() {
		return Goles;
	}

	public void setGoles(int goles) {
		Goles = goles;
	}

	public int getAsistencias() {
		return Asistencias;
	}

	public void setAsistencias(int asistencias) {
		Asistencias = asistencias;
	}

	public int getPartidos_Jugados() {
		return Partidos_Jugados;
	}

	public void setPartidos_Jugados(int partidos_Jugados) {
		Partidos_Jugados = partidos_Jugados;
	}

	public equipos getNombreEQ() {
		return NombreEQ;
	}

	public void setNombreEQ(equipos nombreEQ) {
		NombreEQ = nombreEQ;
	}

	@Override
	public String toString() {
		return "jugadores [Codigo_Jugador=" + Codigo_Jugador + ", Nombre=" + Nombre + ", Edad=" + Edad
				+ ", Nacionalidad=" + Nacionalidad + ", Goles=" + Goles + ", Asistencias=" + Asistencias
				+ ", Partidos_Jugados=" + Partidos_Jugados + ", NombreEQ=" + NombreEQ + "]";
	}
}
