package com.FUTBOLARIOS.Controller;

import org.springframework.web.bind.annotation.GetMapping;

public class ControllerIndex 
{
   @GetMapping("/")
   public String Index()
   {
	  return "index.html";
   }	
}
