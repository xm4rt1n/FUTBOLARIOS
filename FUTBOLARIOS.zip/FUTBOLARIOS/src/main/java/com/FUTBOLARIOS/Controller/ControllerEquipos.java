package com.FUTBOLARIOS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Repository.EquiposRepository;

@Controller
public class ControllerEquipos 
{
	//AUTOWIRED
	@Autowired
	private EquiposRepository Equipo;
	
	//EQUIPOS
	@GetMapping("/Equipos")
	public String MetodoEquipos(Model model)
	{
		List<equipos> equipo = Equipo.findAll();
		model.addAttribute("EQ", equipo);
		return "Equipos";
	}	
}
