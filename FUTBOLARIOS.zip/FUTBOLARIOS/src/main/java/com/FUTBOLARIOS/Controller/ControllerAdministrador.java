package com.FUTBOLARIOS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.FUTBOLARIOS.Entity.administrador;
import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.jugadores;
import com.FUTBOLARIOS.Entity.mensajes;
import com.FUTBOLARIOS.Entity.noticias;
import com.FUTBOLARIOS.Entity.usuarios;
import com.FUTBOLARIOS.Repository.AdministradorRepository;
import com.FUTBOLARIOS.Repository.EquiposRepository;
import com.FUTBOLARIOS.Repository.JugadoresRepository;
import com.FUTBOLARIOS.Repository.MensajesRepository;
import com.FUTBOLARIOS.Repository.NoticiasRepository;
import com.FUTBOLARIOS.Repository.UsuariosRepository;

@Controller
public class ControllerAdministrador
{
   //AUTOWIRED
	@Autowired
	private AdministradorRepository Administrador;
	
	@Autowired
	private JugadoresRepository Jugador;
	
	@Autowired
	private EquiposRepository Equipo;
	
	@Autowired
	private NoticiasRepository Noticia;
	
	@Autowired
	private UsuariosRepository Usuario;
	
	@Autowired
	private MensajesRepository Mensaje;
	
   //ADMINISTRADOR
   @GetMapping("/Administrador")
   public String MetodoAdministrador()
   {
	   return "Iniciar_SesionAdministrador";
   }
   
   @RequestMapping(value = "/Administrador/Menu" , method = RequestMethod.POST)
   public String MetodoAdministradorMenu(Model model, @RequestParam (required = false, defaultValue = "") String nombre, @RequestParam (required = false, defaultValue = "") String contraseña)
   {
		List<administrador> AD = Administrador.findAll();
		administrador admi = new administrador(nombre,contraseña);
			
		if(AD.contains(admi))
		{   
			administrador admi2 = new administrador(nombre,contraseña);
				
		    int index = AD.indexOf(admi);
		    admi = AD.get(index);
				
			if(admi.getContraseña().equals(admi2.getContraseña()))
			{
			   return "Menu_Administrador";
			}
			else
			{
			   return "ErrorContraseñaAdministrador";
			}
		}	
		else
		{
			model.addAttribute("usuario", nombre);
			return "ErrorNombreAdministrador";
		}	
   }  
   
   @RequestMapping(value = "/Administrador/Menu2" , method = RequestMethod.POST)
   public String MetodoAdministradorMenu2()
   {
      return "Menu_Administrador";
   } 
   
   //NOTICIAS.
   @GetMapping("/Administrador/Menu/Noticias")
   public String MetodoAdministradorMenuNoticias()
   {
	   return "Menu_Noticias";
   }
   
   @GetMapping("/Administrador/Menu/Noticia/Eliminar")
   public String MetodoAdministradorMenuNoticiaEliminar(Model model)
   {
	   List<noticias> NO = Noticia.findAll();
	   model.addAttribute("NO", NO);
	   return "NoticiasEliminar";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Noticia/EliminarNoticia/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuNoticiaFinal(Model model, @RequestParam (required = false, defaultValue = "") int[] codigo)
   {	  
	   if(codigo.length != 0)
	   {
	      for(int i=0; i <codigo.length; i++)
	      {
		     Noticia.deleteById(codigo[i]);
          }
		  return "redirect:/Administrador/Menu/Noticia/Eliminar";  
       } 
	   
	   return "redirect:/Administrador/Menu/Noticia/Eliminar";  
   }
  
   @GetMapping("/Administrador/Menu/Noticia/CrearNoticia")
   public String MetodoAdministradorMenuNoticiasCrear(Model model)
   {
	   List<equipos> EQ = Equipo.findAll();
	   model.addAttribute("EQ", EQ);
	   
	   return "CrearNoticias";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Noticia/CrearNoticia/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuNoticiaCrearFinal(Model model, @RequestParam (required = false, defaultValue = "") String NombreEscritor, @RequestParam (required = false, defaultValue = "") String ApellidosEscritor, @RequestParam (required = false, defaultValue = "") String Titulo, @RequestParam (required = false, defaultValue = "") String Texto, @RequestParam (required = false, defaultValue = "") String Fecha, @RequestParam (required = false, defaultValue = "") String equipo)
   {	    
	  equipos EQ = Equipo.getOne(equipo);
	  noticias NO = new noticias(NombreEscritor,ApellidosEscritor,Titulo,Texto,Fecha,EQ);
	  Noticia.save(NO);
	  
      return "NoticiaCreada";
   }  
   
   //EQUIPOS.
   @GetMapping("/Administrador/Menu/Equipos")
   public String MetodoAdministradorMenuEquipos()
   {
	   return "Menu_Equipos";
   }
   
   @GetMapping("/Administrador/Menu/Equipos/Eliminar")
   public String MetodoAdministradorMenuEquiposEliminar(Model model)
   {
	   List<equipos> EQ = Equipo.findAll();
	   model.addAttribute("EQ", EQ);
	   return "EquiposAdministrador";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Equipos/Eliminar/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuEquiposEliminarFinal(Model model, @RequestParam (required = false, defaultValue = "") String[] codigo)
   {	  
	   if(codigo.length != 0)
	   {
	      for(int i=0; i <codigo.length; i++)
	      {
		     Equipo.deleteById(codigo[i]);
          }
		  return "redirect:/Administrador/Menu/Equipos/Eliminar";  
       } 
	   
	   return "redirect:/Administrador/Menu/Equipos/Eliminar";  
   }
   
   @GetMapping("/Administrador/Menu/Equipos/CrearEquipo")
   public String MetodoAdministradorMenuEquiposCrear()
   {
	   return "CrearEquipos";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Equipos/CrearEquipo/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuEquiposMenuCrearFinal(Model model, @RequestParam (required = false, defaultValue = "") String Nombre, @RequestParam (required = false, defaultValue = "") int NumJugadores, @RequestParam (required = false, defaultValue = "") int GolesMarcados, @RequestParam (required = false, defaultValue = "") int GolesEncajados, @RequestParam (required = false, defaultValue = "") int PartidosGanados, @RequestParam (required = false, defaultValue = "") int PartidosPerdidos, @RequestParam (required = false, defaultValue = "") int PartidosEmpatados, @RequestParam (required = false, defaultValue = "") int Puntos, @RequestParam (required = false, defaultValue = "") String Escudo )
   {	    
	  
	  List<equipos> equi = Equipo.findAll();
	  for(equipos  E:equi)
	  {
		  if(E.getNombre().equals(Nombre))
		  {
			  return "EquipoYaCreado";
		  }	  
	  }
	  
	  equipos EQ = new equipos(Nombre,NumJugadores,GolesMarcados,GolesEncajados,PartidosGanados,PartidosPerdidos,PartidosEmpatados,Puntos,Escudo);   
	  Equipo.save(EQ);
	  
      return "EquipoCreado";
   }  
   
   //JUGADORES. 
   @GetMapping("/Administrador/Menu/Jugadores")
   public String MetodoAdministradorMenuJugadores()
   {
	   return "Menu_Jugadores";
   }
   
   @GetMapping("/Administrador/Menu/Jugadores/MenuEliminar")
   public String MetodoAdministradorMenuJugadoresMenuEliminar(Model model)
   {
	   List<jugadores> JU = Jugador.findAll();
	   model.addAttribute("JU", JU);
	   return "JugadoresAdministrador";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Jugadores/MenuEliminar/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuJugadoresMenuEliminarFinal(Model model, @RequestParam (required = false, defaultValue = "") int[] codigo)
   {	  
	   if(codigo.length != 0)
	   {
	      for(int i=0; i <codigo.length; i++)
	      {
		     Jugador.deleteById(codigo[i]);
          }
	      
	      return "redirect:/Administrador/Menu/Jugadores/MenuEliminar";
       } 
	   
	   return "redirect:/Administrador/Menu/Jugadores/MenuEliminar";  
   } 
   
   @GetMapping("/Administrador/Menu/Jugadores/MenuCrear")
   public String MetodoAdministradorMenuJugadoresMenuCrear(Model model)
   {
	   List<equipos> EQ = Equipo.findAll();
	   model.addAttribute("EQ", EQ);
	   
	   return "CrearJugador";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Jugadores/MenuCrear/Final", method = RequestMethod.POST)
   public String MetodoAdministradorMenuJugadoresMenuCrearFinal(Model model, @RequestParam (required = false, defaultValue = "") String Nombre, @RequestParam (required = false, defaultValue = "") int Edad, @RequestParam (required = false, defaultValue = "") String Nacionalidad, @RequestParam (required = false, defaultValue = "") int Goles, @RequestParam (required = false, defaultValue = "") int Asistencias, @RequestParam (required = false, defaultValue = "") int PartidosJugados, @RequestParam (required = false, defaultValue = "") String equipo)
   {	    
	  equipos EQ = Equipo.getOne(equipo);
	  
	  jugadores JU = new jugadores(Nombre,Edad,Nacionalidad,Goles,Asistencias,PartidosJugados,EQ);   
	  Jugador.save(JU);
	  
      return "JugadorCreado";
   }  
   
   //USUARIOS.
   @GetMapping("/Administrador/Menu/Usuarios")
   public String MetodoAdministradorMenuUsuarios(Model model)
   {
	   List<usuarios> U = Usuario.findAll();
	   model.addAttribute("U", U);
	   
	   return "UsuariosAdministrador";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Usuarios/Eliminar", method = RequestMethod.POST)
   public String MetodoAdministradorMenuUsuariosEliminar(Model model, @RequestParam (required = false, defaultValue = "") String codigo)
   {	    
      Usuario.deleteById(codigo);
	  
      return "redirect:/Administrador/Menu/Usuarios";
   }  
   
   //FORO.
   @GetMapping("/Administrador/Menu/Foro")
   public String MetodoAdministradorMenuForo(Model model)
   {
	   List<mensajes> U = Mensaje.findAll();
	   model.addAttribute("U", U);
	   
	   return "MensajesAdministrador";
   }
   
   @RequestMapping(value = "/Administrador/Menu/Foro/Eliminar", method = RequestMethod.POST)
   public String MetodoAdministradorMenuForoEliminar(Model model, @RequestParam (required = false, defaultValue = "") int codigo)
   {	    
      Mensaje.deleteById(codigo);
	  
      return "redirect:/Administrador/Menu/Foro";
   }  
}