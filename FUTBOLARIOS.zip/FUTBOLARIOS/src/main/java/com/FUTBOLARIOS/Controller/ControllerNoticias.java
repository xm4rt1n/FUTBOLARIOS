package com.FUTBOLARIOS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.FUTBOLARIOS.Entity.noticias;
import com.FUTBOLARIOS.Repository.NoticiasRepository;

@Controller
public class ControllerNoticias 
{
	//AUTOWIRED
	@Autowired
	private NoticiasRepository Noticia;
	
	//NOTICIAS
	@GetMapping("/Noticias")
	public String MetodoNoticias(Model model)
	{
		List<noticias> noticia = Noticia.findAll();
		model.addAttribute("NO", noticia);
		return "Noticias_Menú";
	}	
	
	@RequestMapping("/Noticias/Avanzado")
	public String MetodoAvanzadoNoticias(Model model, @RequestParam String userName)
	{	
		List<noticias> noticia = Noticia.findAll();
		noticias NO = new noticias(noticia.get(0).getNombre_Escritor(), noticia.get(0).getApellidos_Escritor(), userName, noticia.get(0).getTexto(), noticia.get(0).getFecha(), noticia.get(0).getEquipos_Nombre());
		if(noticia.contains(NO))
		{   
		   int posicion = noticia.indexOf(NO);
		   model.addAttribute("name", noticia.get(posicion));
		}	
		return "Noticias";
	}	
}
