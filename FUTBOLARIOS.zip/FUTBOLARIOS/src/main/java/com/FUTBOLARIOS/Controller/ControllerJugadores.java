package com.FUTBOLARIOS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.jugadores;
import com.FUTBOLARIOS.Repository.EquiposRepository;
import com.FUTBOLARIOS.Repository.JugadoresRepository;

@Controller
public class ControllerJugadores 
{	
	
	//AUTOWIRED
	@Autowired
	private JugadoresRepository Jugador;
	
	@Autowired
	private EquiposRepository Equipo;
	
	//JUGADORES
	@GetMapping("/Jugadores")
	public String MetodoJugadores(Model model)
	{
		List<equipos> equipo = Equipo.findAll();
		model.addAttribute("EQ", equipo);
		return "Jugadores_Menú";
	}	
	
	@RequestMapping("/Jugadores/Avanzado")
	public String MetodoAvanzadoJugadores(Model model, @RequestParam String userName)
	{	
		/*
		if("Real Madrid".equals(userName))
		{
			List<jugadores> jugadores = Jugador.findAllDateTeamRealMadrid();
			model.addAttribute("JU", jugadores);
			return "Jugadores";
		}
		
		if("Barcelona".equals(userName))
		{
			List<jugadores> jugadores = Jugador.findAllDateTeamBarcelona();
			model.addAttribute("JU", jugadores);
			return "Jugadores";
		}
		
		if("Sevilla".equals(userName))
		{
			List<jugadores> jugadores = Jugador.findAllDateTeamSevila();
			model.addAttribute("JU", jugadores);
			return "Jugadores";	
		}
		
		if("Atlético de Madrid".equals(userName))
		{
			List<jugadores> jugadores = Jugador.findAllDateTeamAtleticoDeMadrid();
			model.addAttribute("JU", jugadores);
			return "Jugadores";
		}
		
		return "Jugadores";	
		*/
		
		equipos EQ = Equipo.getOne(userName);
		
		List<jugadores> jugadores = Jugador.findByNombreEQ(EQ);
		model.addAttribute("JU", jugadores);
		return "Jugadores";
	}
}
