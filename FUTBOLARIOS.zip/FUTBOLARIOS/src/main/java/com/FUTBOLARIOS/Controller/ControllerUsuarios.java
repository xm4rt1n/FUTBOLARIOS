package com.FUTBOLARIOS.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.usuarios;
import com.FUTBOLARIOS.Repository.EquiposRepository;
import com.FUTBOLARIOS.Repository.UsuariosRepository;

@Controller
public class ControllerUsuarios 
{
	//AUTOWIRED
	@Autowired
	private UsuariosRepository Usuario;
	
	@Autowired
	private EquiposRepository Equipo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	//USUARIOS
	@GetMapping("/Usuario")
	public String MetodoUsuarios()
	{
		return "Usuarios";
	}
		
	@GetMapping("/Usuario/Registrarse")
	public String MetodoUsuariosRegistrarse(Model model)
	{			
		List<equipos> equipo = Equipo.findAll();
		model.addAttribute("EQ",equipo);
		return "Registrarse";
	}
		
	@RequestMapping("/Usuario/Registrarse/Avanzado")
	public String MetodoAvanzadoRegistrarse(Model model, @RequestParam String apodo, @RequestParam String nombre, @RequestParam String apellido, @RequestParam int edad, @RequestParam String correo, @RequestParam String contrasena, @RequestParam String equipofavorito)
	{					
		List<usuarios> usuario = Usuario.findAll();	
		List<equipos> equipo = Equipo.findAll();
		
		equipos equipoencontrado = new equipos(equipofavorito,0,0,0,0,0,0,0,"jhkkj");
		
		for(equipos EQ:equipo)
		{
			if(EQ.getNombre().equals(equipofavorito))
			{
			   equipoencontrado = EQ;				
			}		
		}	
		
		usuarios US = new usuarios(apodo,nombre,apellido,edad,correo,passwordEncoder.encode(contrasena),equipoencontrado,"USER");
			
		if(usuario.contains(US))
		{ 
			model.addAttribute("apodo", apodo);
		    return "ErrorApodo";
		}   
		else
		{
			Usuario.save(US);
			return "UsuarioRegistrado";
		}
	}
		
	@GetMapping("/Usuario/IniciarSesion")
	public String MetodoUsuariosIniciarSesion()
	{
		return "Iniciar_Sesion";
	}
	
	@GetMapping("/loginError")
	public String MetodoIniciarSesionFallido()
	{
		return "Iniciar_Sesion_Fallido";
	}
	
	@GetMapping("/Bifurcacion")
	public String Bifurcion(Model model, HttpServletRequest request)
	{	
		if(request.isUserInRole("ADMIN"))
		{
			return "redirect:/Administrador/Menu2";
		}
		else
		{
			return "redirect:/Usuario/Menu";
		}
	}
	
	@GetMapping("/Usuario/Menu")
	public String MetodoMenuUsuario()
	{
		return "Menu_Usuario";
	}
	
	/*
	

	@RequestMapping(value = "/Usuario/IniciarSesion/Avanzado", method = RequestMethod.POST)
	public String MetodoAvanzadoIniciarSesion(Model model, @RequestParam (required = false, defaultValue = "") String apodo, @RequestParam (required = false, defaultValue = "") String contraseña)
	{		
		List<usuarios> usuario = Usuario.findAll();
		
		equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");	
		
		usuarios US = new usuarios(apodo,"nombre","apellido",0,"correo",contraseña,equipoencontrado);
			
		if(usuario.contains(US))
		{   
			
			usuarios US2 = new usuarios(apodo,"nombre","apellido",0,"correo",contraseña,equipoencontrado);
				
		    int index = usuario.indexOf(US);
		    US = usuario.get(index);
				
			if(US.getContraseña().equals(US2.getContraseña()))
			{
			   model.addAttribute("usuario", US);
			   return "Perfil_Usuario";
			}
			else
			{
			   return "ErrorContraseña";
			   }
		}	
		else
		{
			model.addAttribute("usuario", apodo);
			return "UsuarioNoRegistrado";
		}	
	}	
		
	@RequestMapping("/Usuario/IniciarSesion/Avanzado/EliminarPerfil")
	public String MetodoEliminarPerfil(@RequestParam String apodo)
	{
       Usuario.deleteById(apodo);
			
		return "UsuarioEliminado";
	}
	
	@RequestMapping("/Usuario/IniciarSesion/Avanzado/ModificarPerfil")
	public String MetodoModificarPerfil(Model model, @RequestParam String apodo)
	{		
		List<equipos> equipo = Equipo.findAll();
		model.addAttribute("EQ",equipo);
		return "ModificarPerfil";
	}
		
	@RequestMapping("/Usuario/IniciarSesion/Avanzado/ModificarPerfil/Fin")
	public String MetodoModificarPerfilFin(Model model, @RequestParam String apodoantiguo, @RequestParam String apodonuevo, @RequestParam String nombre, @RequestParam String apellido, @RequestParam int edad, @RequestParam String correo, @RequestParam String contraseña, @RequestParam String equipofavorito)
	{	   
		if(!apodonuevo.isEmpty())
	    {
			usuarios AU = Usuario.getOne(apodoantiguo);
		    usuarios UC = new usuarios(apodonuevo,AU.getNombre(),AU.getApellidos(),AU.getEdad(),AU.getCorreo(),AU.getContraseña(),AU.getEquipos_Nombre());
			Usuario.save(UC); 
			Usuario.deleteById(apodoantiguo);
			  
		    if(!nombre.isEmpty())
		    {
		    	UC.setNombre(nombre);
		    	Usuario.save(UC);  
		    }	   
		    if(!apellido.isEmpty())
		    {
		    	UC.setApellidos(apellido);
		    	Usuario.save(UC);     
			}
		    if(edad!=Usuario.getOne(apodonuevo).getEdad())
		    {
		    	UC.setEdad(edad);
		    	Usuario.save(UC);   
			}
		    if(!correo.isEmpty())
		    {
		    	UC.setCorreo(correo);
		    	Usuario.save(UC);
		    }
		    if(!contraseña.isEmpty())
		    {
		    	UC.setContraseña(contraseña);
		    	Usuario.save(UC);
			}
		    if(!equipofavorito.isEmpty())
		    {
				List<equipos> equipo = Equipo.findAll();
				
				equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");
				
				for(equipos EQ:equipo)
				{
					if(EQ.getNombre().equals(equipofavorito))
					{
					   equipoencontrado = EQ;				
					}		
				}	
				
				UC.setEquipos_Nombre(equipoencontrado);
		    	Usuario.save(UC);  
			}	   	    
	    }
		else
		{
		    usuarios AU = Usuario.getOne(apodoantiguo); 
				  
		    if(!nombre.isEmpty())
		    {
		    	AU.setNombre(nombre);
		    	Usuario.save(AU);  
		    }	   
		    if(!apellido.isEmpty())
		    {
		    	AU.setApellidos(apellido);
		    	Usuario.save(AU);     
			}
		    if(edad!=Usuario.getOne(apodoantiguo).getEdad())
		    {
		    	AU.setEdad(edad);
		    	Usuario.save(AU);   
			}
		    if(!correo.isEmpty())
		    {
		    	AU.setCorreo(correo);
		    	Usuario.save(AU);
		    }
		    if(!contraseña.isEmpty())
		    {
		    	AU.setContraseña(contraseña);
		    	Usuario.save(AU);
			}
	        if(!equipofavorito.isEmpty())
		    {
				List<equipos> equipo = Equipo.findAll();
				
				equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");
				
				for(equipos EQ:equipo)
				{
					if(EQ.getNombre().equals(equipofavorito))
					{
					   equipoencontrado = EQ;				
					}		
				}	
				
				AU.setEquipos_Nombre(equipoencontrado);
		    	Usuario.save(AU);  
			}	   	    
	    }
	    return "DatosModificados";
	}*/
	
	@GetMapping("/Usuario/Perfil")
	public String MetodoAvanzadoIniciarSesion(Model model, HttpServletRequest request)
	{		
		String usu = request.getUserPrincipal().getName();		
		usuarios use = Usuario.findByApodo(usu).orElseThrow();
	
	    model.addAttribute("usuario", use);
		return "Perfil_Usuario";	
	}	
	
	@RequestMapping("/Usuario/Perfil/EliminarPerfil")
	public String MetodoEliminarPerfil(@RequestParam String apodo)
	{
       Usuario.deleteById(apodo);
			
		return "UsuarioEliminado";
	}
	
	@RequestMapping("/Usuario/Perfil/ModificarPerfil")
	public String MetodoModificarPerfil(Model model)
	{		
		List<equipos> equipo = Equipo.findAll();
		model.addAttribute("EQ",equipo);
		return "ModificarPerfil";
	}
	
	@RequestMapping("/Usuario/Perfil/ModificarPerfil/Fin")
	public String MetodoModificarPerfilFin(Model model, @RequestParam String apodoantiguo, @RequestParam String apodonuevo, @RequestParam String nombre, @RequestParam String apellido, @RequestParam int edad, @RequestParam String correo, @RequestParam String contraseña, @RequestParam String equipofavorito)
	{	   
		if(!apodonuevo.isEmpty())
	    {
			usuarios AU = Usuario.getOne(apodoantiguo);
		    usuarios UC = new usuarios(apodonuevo,AU.getNombre(),AU.getApellidos(),AU.getEdad(),AU.getCorreo(),AU.getContrasena(),AU.getEquipos_Nombre(),"USER");
			Usuario.save(UC); 
			Usuario.deleteById(apodoantiguo);
			  
		    if(!nombre.isEmpty())
		    {
		    	UC.setNombre(nombre);
		    	Usuario.save(UC);  
		    }	   
		    if(!apellido.isEmpty())
		    {
		    	UC.setApellidos(apellido);
		    	Usuario.save(UC);     
			}
		    if(edad!=Usuario.getOne(apodonuevo).getEdad())
		    {
		    	UC.setEdad(edad);
		    	Usuario.save(UC);   
			}
		    if(!correo.isEmpty())
		    {
		    	UC.setCorreo(correo);
		    	Usuario.save(UC);
		    }
		    if(!contraseña.isEmpty())
		    {
		    	UC.setContrasena(contraseña);
		    	Usuario.save(UC);
			}
		    if(!equipofavorito.isEmpty())
		    {
				List<equipos> equipo = Equipo.findAll();
				
				equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");
				
				for(equipos EQ:equipo)
				{
					if(EQ.getNombre().equals(equipofavorito))
					{
					   equipoencontrado = EQ;				
					}		
				}	
				
				UC.setEquipos_Nombre(equipoencontrado);
		    	Usuario.save(UC);  
			}	   	    
	    }
		else
		{
		    usuarios AU = Usuario.getOne(apodoantiguo); 
				  
		    if(!nombre.isEmpty())
		    {
		    	AU.setNombre(nombre);
		    	Usuario.save(AU);  
		    }	   
		    if(!apellido.isEmpty())
		    {
		    	AU.setApellidos(apellido);
		    	Usuario.save(AU);     
			}
		    if(edad!=Usuario.getOne(apodoantiguo).getEdad())
		    {
		    	AU.setEdad(edad);
		    	Usuario.save(AU);   
			}
		    if(!correo.isEmpty())
		    {
		    	AU.setCorreo(correo);
		    	Usuario.save(AU);
		    }
		    if(!contraseña.isEmpty())
		    {
		    	AU.setContrasena(contraseña);
		    	Usuario.save(AU);
			}
	        if(!equipofavorito.isEmpty())
		    {
				List<equipos> equipo = Equipo.findAll();
				
				equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");
				
				for(equipos EQ:equipo)
				{
					if(EQ.getNombre().equals(equipofavorito))
					{
					   equipoencontrado = EQ;				
					}		
				}	
				
				AU.setEquipos_Nombre(equipoencontrado);
		    	Usuario.save(AU);  
			}	   	    
	    }
	    return "DatosModificados";
	}
}
