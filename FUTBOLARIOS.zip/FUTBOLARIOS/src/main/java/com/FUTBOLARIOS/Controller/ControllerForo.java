package com.FUTBOLARIOS.Controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.FUTBOLARIOS.Entity.equipos;
import com.FUTBOLARIOS.Entity.mensajes;
import com.FUTBOLARIOS.Entity.usuarios;
import com.FUTBOLARIOS.Repository.MensajesRepository;
import com.FUTBOLARIOS.Repository.UsuariosRepository;

@Controller
public class ControllerForo 
{
	//AUTOWIRED
	@Autowired
	private UsuariosRepository Usuario;
	
	@Autowired
	private MensajesRepository Mensaje;	
	
	//FORO
	@GetMapping("/Foro")
	public String MetodoForo()
	{
		return "Iniciar_SesionForo";
	}

	@RequestMapping(value = "/Foro/IniciarSesionForo", method = RequestMethod.POST)
	public String MetodoForoIniciarSesion(Model model, @RequestParam (required = false, defaultValue = "") String apodo, @RequestParam (required = false, defaultValue = "") String contraseña)
	{	
		equipos equipoencontrado = new equipos("",0,0,0,0,0,0,0,"");
		
		List<usuarios> usuario = Usuario.findAll();
		usuarios US = new usuarios(apodo,"nombre","apellido",0,"correo",contraseña,equipoencontrado);
			
		if(usuario.contains(US))
		{   
			usuarios US2 = new usuarios(apodo,"nombre","apellido",0,"correo",contraseña,equipoencontrado);
				
		    int index = usuario.indexOf(US);
		    US = usuario.get(index);
				
			if(US.getContraseña().equals(US2.getContraseña()))
			{
			   List<mensajes> Mensajes = Mensaje.findAll();
			   model.addAttribute("usuario", US);
			   model.addAttribute("mensajes", Mensajes);
			   return "Foro";
			}
			else
			{
			   return "ErrorContraseñaForo";
			}
		}	
		else
		{
			model.addAttribute("usuario", apodo);
			return "ErrorApodoForo";
		}	
	}
			
	@RequestMapping(value = "/Foro/IniciarSesionForo/Actualizada", method = RequestMethod.POST)
	public String MetodoForoIniciarSesionActualizada(Model model, @RequestParam (required = false, defaultValue = "") String mensaje, @RequestParam (required = false, defaultValue = "") String apodo)
	{
		SimpleDateFormat formatofecha = new SimpleDateFormat("yyyy-MM-dd");
		Date fecha = new Date();
		
		usuarios US = Usuario.getOne(apodo);
		
		mensajes MN = new mensajes(mensaje,formatofecha.format(fecha),US);
			
		Mensaje.save(MN);
			
		return "ComentarioRealizado";		
	}	
}
